/**
 * Program: Craps.java
 * Purpose: Primary gui class for a craps casino game with 2-6 players
 * Author: Henry Menary, Jason Fink
 * Date: Apr. 11, 2023
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
public class Craps extends JFrame
{
	private int numPlayers;
	private String[] playerNames;
	private Game game;
	private ArrayList<Player> playerList;
	private Die die1 = new Die();
	private Die die2 = new Die();
	private Pass pass = new Pass(0,0,0);
	private int winRoll;
	private int shooterID;
	private boolean passTheDice = false;//this is used for the pass the dice button
	
	private JTextField txtFld1;
	private JTextField txtFld2;
	private JTextField txtFld3;
	private JTextField txtFld4;
	private JTextField txtFld5;
	private JTextField txtFld6;
	private JTextField rollScoreTxt;
	private JTextField rollNumTxt;
	private JTextField winFld;
	
	private JTextField[] betArray;
	private JTextField[] bankArray;
	private JTextField betFld1;
	private JTextField betFld2;
	private JTextField betFld3;
	private JTextField betFld4;
	private JTextField betFld5;
	private JTextField betFld6;
	
	private JTextField shooterFld;
	
	private JTextField betStatusField;
	
	
	public Craps(int numPlayers, String[] playerNames)
	{
		super("Craps");
		//standard GUI BOILERPLATE CODE
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setSize(700, 300);
		this.setLocationRelativeTo(null);
		this.setLayout(new BorderLayout());
		
    JMenuBar menuBar = new JMenuBar();
    
    
    JMenu aboutMenu = new JMenu("Menu");
    JMenuItem aboutItem = new JMenuItem("About");
    JMenuItem instrItem = new JMenuItem("Instructions");
    aboutMenu.add(instrItem);
    aboutMenu.add(aboutItem);
    menuBar.add(aboutMenu);
    aboutItem.addActionListener(e -> {
      JOptionPane.showMessageDialog(menuBar, "Created by Henry Menary and Jason Fink");
    });
   
    instrItem.addActionListener(e -> {
        JOptionPane.showMessageDialog(menuBar, "How To Play: The game picks and displays a shooter. The shooter will bet on themselves and roll the dice. \nEveyone else has the option to cover part of the bet with a multiple of ten with the max being the amount the shooter bet themselves. \nIf the shooter rolls a 7 on the opening roll, the shooter wins and has the option to pass along the dice. \nIf the shooter rolls a 2, 3, or 12 on their first roll, they lose. \nHowever, after the first roll, the shooter has to match the roll they got first before rolling another 7 to win. \nThe winner of the entire game is determined by who gets everyone elses money first. \nIf a player has no money left, they are out.");
      });
    
    
		
		JPanel topPnl = new JPanel();
		JPanel midPnl = new JPanel();
		JPanel bottomPnl = new JPanel();
		
		betArray = new JTextField[6];
		
		betFld1 = new JTextField("");
		betFld2 = new JTextField("");
		betFld3 = new JTextField("");
		betFld4 = new JTextField("");
		betFld5 = new JTextField("");
		betFld6 = new JTextField("");
		
		betArray[0] = betFld1;
		betArray[1] = betFld2;
		betArray[2] = betFld3;
		betArray[3] = betFld4;
		betArray[4] = betFld5;
		betArray[5] = betFld6;
		
		winFld = new JTextField("Winner: N/A		");
		
		shooterID = (int)((Math.random() * (numPlayers - 0)) + 0);
		shooterFld = new JTextField("Shooter: "+playerNames[shooterID]);
		midPnl.add(shooterFld);
		
		JLabel name1 = new JLabel(playerNames[0] + " Bank Balance");
		JLabel name2 = new JLabel(playerNames[1] + " Bank Balance");
		JLabel name3 = new JLabel(playerNames[2] + " Bank Balance");
		JLabel name4 = new JLabel(playerNames[3] + " Bank Balance");
		JLabel name5 = new JLabel(playerNames[4] + " Bank Balance");
		JLabel name6 = new JLabel(playerNames[5] + " Bank Balance");
		
		JLabel betName1 = new JLabel(playerNames[0] + " bet");
		JLabel betName2 = new JLabel(playerNames[1] + " bet");
		JLabel betName3 = new JLabel(playerNames[2] + " bet");
		JLabel betName4 = new JLabel(playerNames[3] + " bet");
		JLabel betName5 = new JLabel(playerNames[4] + " bet");
		JLabel betName6 = new JLabel(playerNames[5] + " bet");
		
		JLabel emptyLbl = new JLabel("Empty");
		JLabel emptyLbl2 = new JLabel("Empty");
		JLabel emptyLbl3 = new JLabel("Empty");
		JLabel emptyLbl4 = new JLabel("Empty");
		
		JButton shootBtn = new JButton("Roll");
		midPnl.add(shootBtn);
		
		JButton newShooterBtn = new JButton("Pass the dice");
		
		this.playerNames = playerNames;
		
		this.numPlayers = numPlayers;
		
		this.playerList = new ArrayList<Player>();
		
		addPlayers(this.numPlayers);
		
		game = new Game(numPlayers);
		
		game.populatePlayerList(playerList);
		
		txtFld1 = new JTextField("100");
		txtFld2 = new JTextField("100");
		txtFld3 = new JTextField("100");
		txtFld4 = new JTextField("100");
		txtFld5 = new JTextField("100");
		txtFld6 = new JTextField("100");
		
		bankArray = new JTextField[6];
		bankArray[0] = txtFld1;
		bankArray[1] = txtFld2;
		bankArray[2] = txtFld3;
		bankArray[3] = txtFld4;
		bankArray[4] = txtFld5;
		bankArray[5] = txtFld6;
		
		rollScoreTxt = new JTextField("	");
		rollNumTxt = new JTextField("	");
		
		betStatusField = new JTextField("Place Bets		");
		
		JLabel rollLbl = new JLabel("Amount Rolled:");
		JLabel rollNumLbl = new JLabel("Roll #:");
		midPnl.add(rollLbl);
		midPnl.add(rollScoreTxt);
		midPnl.add(rollNumLbl);
		midPnl.add(rollNumTxt);
		midPnl.add(betStatusField);
		
		if(numPlayers == 2) {
			topPnl.add(name1);
			topPnl.add(txtFld1);
			topPnl.add(name2);
			topPnl.add(txtFld2);
			bottomPnl.add(betName1);
			bottomPnl.add(betName2);
			bottomPnl.add(emptyLbl);
			bottomPnl.add(emptyLbl2);
			bottomPnl.add(emptyLbl3);
			bottomPnl.add(emptyLbl4);
		}
		else if(numPlayers == 3) {
			topPnl.add(name1);
			topPnl.add(txtFld1);
			topPnl.add(name2);
			topPnl.add(txtFld2);
			topPnl.add(name3);
			topPnl.add(txtFld3);
			bottomPnl.add(betName1);
			bottomPnl.add(betName2);
			bottomPnl.add(betName3);
			bottomPnl.add(emptyLbl);
			bottomPnl.add(emptyLbl2);
			bottomPnl.add(emptyLbl3);
		}
		else if(numPlayers == 4) {
			topPnl.add(name1);
			topPnl.add(txtFld1);
			topPnl.add(name2);
			topPnl.add(txtFld2);
			topPnl.add(name3);
			topPnl.add(txtFld3);
			topPnl.add(name4);
			topPnl.add(txtFld4);
			bottomPnl.add(betName1);
			bottomPnl.add(betName2);
			bottomPnl.add(betName3);
			bottomPnl.add(betName4);
			bottomPnl.add(emptyLbl);
			bottomPnl.add(emptyLbl2);
		}
		else if(numPlayers == 5) {
			topPnl.add(name1);
			topPnl.add(txtFld1);
			topPnl.add(name2);
			topPnl.add(txtFld2);
			topPnl.add(name3);
			topPnl.add(txtFld3);
			topPnl.add(name4);
			topPnl.add(txtFld4);
			topPnl.add(name5);
			topPnl.add(txtFld5);
			bottomPnl.add(betName1);
			bottomPnl.add(betName2);
			bottomPnl.add(betName3);
			bottomPnl.add(betName4);
			bottomPnl.add(betName5);
			bottomPnl.add(emptyLbl);
		}
		else if(numPlayers == 6) {
			topPnl.add(name1);
			topPnl.add(txtFld1);
			topPnl.add(name2);
			topPnl.add(txtFld2);
			topPnl.add(name3);
			topPnl.add(txtFld3);
			topPnl.add(name4);
			topPnl.add(txtFld4);
			topPnl.add(name5);
			topPnl.add(txtFld5);
			topPnl.add(name6);
			topPnl.add(txtFld6);
			bottomPnl.add(betName1);
			bottomPnl.add(betName2);
			bottomPnl.add(betName3);
			bottomPnl.add(betName4);
			bottomPnl.add(betName5);
			bottomPnl.add(betName6);
		}
		
		bottomPnl.add(betFld1);
		bottomPnl.add(betFld2);
		bottomPnl.add(betFld3);
		bottomPnl.add(betFld4);
		bottomPnl.add(betFld5);
		bottomPnl.add(betFld6);
		
		midPnl.add(newShooterBtn);
		midPnl.add(winFld);
		midPnl.add(menuBar);
		
		topPnl.setLayout(new GridLayout(6,2));
		bottomPnl.setLayout(new GridLayout(2,6));
		this.add(topPnl, BorderLayout.NORTH);
		this.add(midPnl, BorderLayout.CENTER);
		this.add(bottomPnl, BorderLayout.SOUTH);
		
		Listener nanny = new Listener();
		shootBtn.addActionListener(nanny);
		newShooterBtn.addActionListener(nanny);
			
		this.setVisible(true);
	}
	
	public void addPlayers(int num)
	{
		for(int i = 0; i < num; i++)
		{
			this.playerList.add(new Player(playerNames[i]));
		}
	}
	
	private class Listener implements ActionListener
	{
		private int rollNum = 0;
		private int rollAmt = 0;
		private int shooterNum;
		private boolean gameWon = false;
		
		@Override
		public void actionPerformed(ActionEvent e)
		{
			
			if(e.getActionCommand().equals("Roll"))
			{
				boolean isComeOutRoll;
				if(rollNum ==0)
				{
					isComeOutRoll = true;
				}
				else {
					isComeOutRoll = false;
				}
				shooterNum = shooterID;
				
				playerList.get(shooterNum).setIsShooter(true);
				pass.setShooterID(shooterNum);
				
				this.rollAmt = die1.rollDie() + die2.rollDie();
				rollNum++;
				String rollAmtStr = "" + rollAmt;
				String rollNumStr = "" + rollNum;
				System.out.println(rollAmt);
				rollScoreTxt.setText(rollAmtStr);
				rollNumTxt.setText(rollNumStr);
				
				passTheDice = false;
				
				int actionCovered = 0;
				//loop through playerList and count the betArray for each active player to get action covered
				if(isComeOutRoll) 
				{
					
					for(int i = 0; i < numPlayers; i++)
					{
						if(i == shooterNum && playerList.get(i).getIsOut() == false)
						{
							String actionString = betArray[i].getText();
							if(Integer.parseInt(actionString) % 10 == 0 && Integer.parseInt(actionString) <= playerList.get(i).getBankBalance())
							{
								pass.setActionAmount(Integer.parseInt(actionString));
							}
						}			
					}

					for(int i = 0; i < numPlayers; i++)
					{
						if(i != shooterNum && playerList.get(i).getBankBalance() > 0 && playerList.get(i).getIsOut() == false)
						{
							
							String betString = betArray[i].getText();
											
							if(Integer.parseInt(betString) % 10 == 0 && Integer.parseInt(betString) <= pass.getActionAmount() - actionCovered)
							{
								
								if(playerList.get(i).getBankBalance() >= Integer.parseInt(betString))
								{
									playerList.get(i).setAmountBet(Integer.parseInt(betString));
									actionCovered += Integer.parseInt(betString);
									pass.setActionAmountCovered(actionCovered);
									
								}
								else
								{
									rollAmt = 0;
									rollNum = 0;
									rollScoreTxt.setText(rollAmtStr);
									rollNumTxt.setText(rollNumStr);
									actionCovered = 0;
									break;
								}
								
							}
							else {
								rollAmt = 0;
								rollNum = 0;
								rollScoreTxt.setText(rollAmtStr);
								rollNumTxt.setText(rollNumStr);
								actionCovered = 0;
								break;
							}
							
							if(actionCovered == pass.getActionAmount())
							{
								betStatusField.setText("ACTION COVERED");
							}
							
							winRoll = rollAmt;
						}
					}
					
				}//end of come out roll

				
				if(this.rollAmt == 7  && isComeOutRoll == true || this.rollAmt == 11 && isComeOutRoll == true)
				{
					pass.setShooterWinOrLose(true);
					pass.settleBets(true, playerList);
					isComeOutRoll = true;
					rollAmt = 0;
					rollNum = 0;
					rollScoreTxt.setText(rollAmtStr);
					rollNumTxt.setText(rollNumStr);
					actionCovered = 0;
					passTheDice = true;
					gameWon = game.checkForGameWinner(playerList);
					
				}
				else if(this.rollAmt == 2 && isComeOutRoll == true|| this.rollAmt == 3 && isComeOutRoll == true|| this.rollAmt == 12 && isComeOutRoll == true)
				{
					pass.setShooterWinOrLose(false);
					pass.settleBets(false, playerList);
					isComeOutRoll = true;
					rollAmt = 0;
					rollNum = 0;
					rollScoreTxt.setText(rollAmtStr);
					rollNumTxt.setText(rollNumStr);
					actionCovered = 0;
					passTheDice = true;
					gameWon = game.checkForGameWinner(playerList);
				}
				else if(winRoll == rollAmt && isComeOutRoll == false)
				{
					pass.setShooterWinOrLose(true);
					pass.settleBets(true, playerList);
					isComeOutRoll = true;
					rollAmt = 0;
					rollNum = 0;
					rollScoreTxt.setText(rollAmtStr);
					rollNumTxt.setText(rollNumStr);
					actionCovered = 0;
					passTheDice = true;
					gameWon = game.checkForGameWinner(playerList);
				}
				else if(rollAmt == 7 && isComeOutRoll == false)
				{
					pass.setShooterWinOrLose(false);
					pass.settleBets(false, playerList);
					isComeOutRoll = true;
					rollAmt = 0;
					rollNum = 0;
					rollScoreTxt.setText(rollAmtStr);
					rollNumTxt.setText(rollNumStr);
					actionCovered = 0;
					passTheDice = true;
					gameWon = game.checkForGameWinner(playerList);
				}
				else {
					isComeOutRoll = false;
				}
				
				
				for(int i = 0; i < numPlayers; i++)
				{
					String bankBalance = "" + playerList.get(i).getBankBalance();
					bankArray[i].setText(bankBalance);
					
					if(playerList.get(i).getBankBalance() == 0)
					{
						playerList.get(i).setIsOut(true);
						betArray[i].setText("OUT");
					}
				}
				
				if(gameWon)
				{
					for(int i = 0; i < playerList.size(); i++)
					{
						if(playerList.get(i).getBankBalance() == game.getTotalPotAmount())
						{
							winFld.setText("Winner: "+ playerNames[i]);
						}
					}
					
					
				}
				
			}
			
			if(e.getActionCommand().equals("Pass the dice"))
			{
				if(passTheDice = true)
				{
					shooterID = (int)((Math.random() * (numPlayers - 0)) + 0);
					shooterFld.setText("Shooter: "+playerNames[shooterID]);
					
					for(int i = 0; i < numPlayers; i++)
					{
						playerList.get(i).setIsShooter(false);
					}
					
				}
			}
		}
		
	}

	//end main
}
// end class