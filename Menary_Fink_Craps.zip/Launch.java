/**
 * Program: Craps.java
 * Purpose: Primary gui class for the craps game program
 * Author: Henry Menary, Jason Fink
 * Date: Apr. 11, 2023
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Launch extends JFrame
{
	private int numPlayers;
	private String[] playerNames;
	private JTextField txtFld1;
	private JTextField txtFld2;
	private JTextField txtFld3;
	private JTextField txtFld4;
	private JTextField txtFld5;
	private JTextField txtFld6;
	private JTextField txtFld7;
	
	public Launch()
	{
		super("Craps");
		//standard GUI BOILERPLATE CODE
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setSize(300, 300);
		this.setLocationRelativeTo(null);
		this.setLayout(new GridLayout(3,1));
	
		
		JPanel pnl1 = new JPanel();
		JPanel pnl2 = new JPanel();
		JPanel pnl3 = new JPanel();
		JLabel lbl1 = new JLabel("How Many Players?");
		
		LaunchListener listener = new LaunchListener();
		
		JLabel lbl2 = new JLabel("Player Names:");
		txtFld1 = new JTextField("2");
		txtFld2 = new JTextField("Player 1");
		txtFld3 = new JTextField("Player 2");
		txtFld4 = new JTextField("Player 3");
		txtFld5 = new JTextField("Player 4");
		txtFld6 = new JTextField("Player 5");
		txtFld7 = new JTextField("Player 6");
    
		JButton btn = new JButton("Confirm");
		btn.addActionListener(listener);
		
		pnl1.add(lbl1);
		pnl1.add(txtFld1);
		
		pnl2.add(lbl2);
		pnl2.add(txtFld2);
		pnl2.add(txtFld3);
		pnl2.add(txtFld4);
		pnl2.add(txtFld5);
		pnl2.add(txtFld6);
		pnl2.add(txtFld7);
		
		pnl3.add(btn);
		
		this.add(pnl1);
		this.add(pnl2);
		this.add(pnl3);
		
		this.setVisible(true);
	}
	
	private class LaunchListener implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e)
		{
			if(e.getActionCommand().equals("Confirm"))
			{
				String numString = txtFld1.getText();
				numPlayers = Integer.parseInt(numString);
				
				String name1 = txtFld2.getText();
				String name2 = txtFld3.getText();
				String name3 = txtFld4.getText();
				String name4 = txtFld5.getText();
				String name5 = txtFld6.getText();
				String name6 = txtFld7.getText();
				
				playerNames = new String[6];
				
				playerNames[0] = name1;
				playerNames[1] = name2;
				playerNames[2] = name3;
				playerNames[3] = name4;
				playerNames[4] = name5;
				playerNames[5] = name6;
				
				
				dispose();
				
				Craps craps = new Craps(numPlayers, playerNames);
			}
		}
		
	}
	

	
	public static void main(String[] args)
	{
		new Launch();
	}
	//end main
}
// end class