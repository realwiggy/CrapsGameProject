import java.util.ArrayList;

/**
 * Program: Pass.java
 * Purpose: 
 * Author: Henry Menary, Jason Fink
 * Date: Apr. 10, 2023
 */

public class Pass
{
	private int shooterID;
	private int actionAmount;
	private int actionAmountCovered;
	private boolean shooterWin;
	
	public Pass(int shooterID, int actionAmount, int actionAmountCovered)
	{
		this.shooterID = shooterID;
		this.actionAmount = actionAmount;
		this.actionAmountCovered = actionAmountCovered;
		this.shooterWin = false;
	}

	public int getShooterID()
	{
		return shooterID;
	}

	public int getActionAmount()
	{
		return actionAmount;
	}

	public int getActionAmountCovered()
	{
		return actionAmountCovered;
	}

	public boolean getShooterWinOrLose()
	{
		return shooterWin;
	}

	public void setShooterID(int index)
	{
		this.shooterID = index;
	}

	public void setActionAmount(int actionAmount)
	{
		this.actionAmount = actionAmount;
	}

	public void setActionAmountCovered(int actionAmountCovered)
	{
		this.actionAmountCovered = actionAmountCovered;
	}

	public void setShooterWinOrLose(boolean shooterWin)
	{
		this.shooterWin = shooterWin;
	}
	
	public void settleBets(boolean shooterWin, ArrayList<Player> playerList)
	{
		for(int i = 0; i < playerList.size(); i++)
		{
			if(playerList.get(i).getIsShooter() == true)
			{
				if(this.shooterWin == true)
				{
					playerList.get(i).setBankBalance(playerList.get(i).getBankBalance() + this.actionAmountCovered);
				}
				else {
					playerList.get(i).setBankBalance(playerList.get(i).getBankBalance() - this.actionAmountCovered);
				}
			}
			else {
				if(this.shooterWin == true)
				{
					playerList.get(i).setBankBalance(playerList.get(i).getBankBalance() - playerList.get(i).getAmountBet());
				}
				else {
					playerList.get(i).setBankBalance(playerList.get(i).getBankBalance() + playerList.get(i).getAmountBet());
				}
			}
		}
	}
	
	public boolean shootOrPass()
	{
		return true;
	}
	
}

// end class