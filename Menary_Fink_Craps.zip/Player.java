/**
 * Program: Player.java
 * Purpose: 
 * Author: Henry Menary, Jason Fink
 * Date: Apr. 10, 2023
 */

public class Player
{
	private String name;
	private int bankBalance;
	private boolean isShooter;
	private int betAmount;
	private boolean passCompleted;
	private boolean isOut;
	
	public Player(String name)
	{
		this.name = name;
		this.bankBalance = 100;
		this.isShooter = false;
		this.passCompleted = false;
		this.isOut = false;
	}

	public String getName()
	{
		return name;
	}

	public int getBankBalance()
	{
		return bankBalance;
	}
	
	public void setBankBalance(int bankBalance)
	{
		this.bankBalance = bankBalance;
	}

	public boolean getIsShooter()
	{
		return isShooter;
	}

	public int getAmountBet()
	{
		return betAmount;
	}

	public void setAmountBet(int betAmount)
	{
		this.betAmount = betAmount;
	}
	
	public boolean getPassCompleted()
	{
		return passCompleted;
	}
	
	public void setPassCompleted(boolean passCompleted)
	{
		this.passCompleted = passCompleted;
	}
	
	public void setIsShooter(boolean isShooter)
	{
		this.isShooter = isShooter;
	}
	public void setIsOut(boolean isOut)
	{
		this.isOut = isOut;
	}
	public boolean getIsOut()
	{
		return this.isOut;
	}


	
	
}
// end class