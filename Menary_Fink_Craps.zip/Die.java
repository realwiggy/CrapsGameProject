/**
 * Program: Die.java
 * Purpose: 
 * Author: Henry Menary, Jason Fink
 * Date: Apr. 10, 2023
 */

public class Die
{
	private int rollValue;
	
	public Die()
	{
		this.rollValue = 0;
	}
	
	public int getRollValue()
	{
		return this.rollValue;
	}
	
	public int rollDie()
	{
		this.rollValue = (int)((Math.random() * (6 - 1)) + 1);
		return this.rollValue;
	}
}
// end class