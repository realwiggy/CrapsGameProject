/**
 * Program: Game.java
 * Purpose: Game class  for craps project
 * Author: Henry Menary, Jason Fink
 * Date: Apr. 10, 2023
 */
import java.util.*;
public class Game
{
	private int totalPotAmount;
	private ArrayList<Player> playerList;
	
	public Game(int numPlayers)
	{
		this.totalPotAmount = 100 * numPlayers;
		this.playerList = new ArrayList<Player>();
		
	}

	public int getTotalPotAmount()
	{
		return this.totalPotAmount;
	}

	public ArrayList<Player> getPlayerList()
	{
		return this.playerList;
	}
	
	public void populatePlayerList(ArrayList<Player> playerList)
	{
		for(int i = 0; i < playerList.size(); i++)
		{
			this.playerList.add(playerList.get(i));
		}
	}
	
	public boolean checkForGameWinner(ArrayList<Player> playerList)
	{
		for(int i = 0; i < playerList.size(); i++)
		{
			if(playerList.get(i).getBankBalance() == this.totalPotAmount)
			{
				return true;
			}
		}
		return false;
	}
	
	

	
	
}
// end class